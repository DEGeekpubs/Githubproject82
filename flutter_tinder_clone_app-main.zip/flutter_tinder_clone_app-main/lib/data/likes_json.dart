const List likes_json = [
  {"img": "assets/images/girls/img_11.jpeg", "active": true},
  {"img": "assets/images/girls/img_12.jpeg", "active": false},
  {"img": "assets/images/girls/img_13.jpeg", "active": false},
  {"img": "assets/images/girls/img_14.jpeg", "active": true},
  {"img": "assets/images/girls/img_15.jpeg", "active": true},
  {"img": "assets/images/girls/img_16.jpeg", "active": true},
];
