const List item_icons = [
  {
    "icon": "assets/images/refresh_icon.svg",
    "size": 45.0,
    "icon_size": 20.0,
  },
  {
    "icon": "assets/images/close_icon.svg",
    "size": 58.0,
    "icon_size": 25.0,
  },
  {
    "icon": "assets/images/star_icon.svg",
    "size": 45.0,
    "icon_size": 25.0,
  },
  {
    "icon": "assets/images/like_icon.svg",
    "size": 57.0,
    "icon_size": 27.0,
  },
  {
    "icon": "assets/images/thunder_icon.svg",
    "size": 45.0,
    "icon_size": 17.0,
  }
];
